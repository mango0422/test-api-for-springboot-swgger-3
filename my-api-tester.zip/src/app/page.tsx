import ApiTester from "@/components/api-tester";

export default function Home() {
  return (
    <main className="container mx-auto py-6 px-4 min-h-screen">
      <ApiTester />
    </main>
  );
}
